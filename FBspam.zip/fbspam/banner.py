#!/usr/bin/python
# coding=utf-8
#///.coded by MR.K7C8NG
import time
import os,sys


def prRed(skk): print("\033[91m {}\033[00m" .format(skk)) 
def prGreen(skk): print("\033[92m {}\033[00m" .format(skk)) 
def prYellow(skk): print("\033[93m {}\033[00m" .format(skk)) 
def prLightPurple(skk): print("\033[94m {}\033[00m" .format(skk)) 
def prPurple(skk): print("\033[95m {}\033[00m" .format(skk)) 
def prCyan(skk): print("\033[96m {}\033[00m" .format(skk)) 
def prLightGray(skk): print("\033[97m {}\033[00m" .format(skk)) 
def prBlack(skk): print("\033[98m {}\033[00m" .format(skk)) 

green = '\033[32;1m'

gta = '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'
  #//Colors 
white = '\033[1;37m' # White 
red = '\033[31m' # red
orange = '\033[33m' # orange
blue = '\033[34m' # blue
p  = '\033[35m' # purple
C  = '\033[36m' # cyan
green = ("\033[92m")
pryellow = ("\033[93m")
prLightPurple=("\033[94m")
prCyan=("\033[96m")
prgray = ("\033[97m")
prBlack=("\033[98m")



class fbspam:
  def __init__(self):
      print
      print pryellow+"""
 / _| |__  ___ _ __   __ _ _ __ ___
| |_| '_ \/ __| '_ \ / _` | '_ ` _ \ 
|  _| |_) \__ \ |_) | (_| | | | | | | 
|_| |_.__/|___/ .__/ \__,_|_| |_| |_|
              |_|
          [Facebook Multi Tool  2019]\n"""+C+p+"""      Instagram : @pranata_pasha
       github: https://github.com/pashayogi
       developer: MR.K7C8NG
       """
      print '-'*43
        
 





       
       
       

       
if __name__ == "__main__":
	fbspam()